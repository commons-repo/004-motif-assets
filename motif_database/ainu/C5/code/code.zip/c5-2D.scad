include<openscad_template.scad>

points_1 = include <formatted_data_1.txt>;

points_2 = include <formatted_data_2.txt>;

points_3 = include <formatted_data_3.txt>;

points_4 = include <formatted_data_4.txt>;

points_5 = include <formatted_data_5.txt>;

points_6 = include <formatted_data_6.txt>;

points_7 = include <formatted_data_7.txt>;

points_8 = include <formatted_data_8.txt>;

create_2d_path (points_set=points_1, width=1,
fragments=50, shape="circle");

create_2d_path (points_set=points_2, width=1,
fragments=50, shape="circle");

create_2d_path (points_set=points_3, width=1,
fragments=50, shape="circle");

create_2d_path (points_set=points_4, width=1,
fragments=50, shape="circle");

create_2d_path (points_set=points_5, width=1,
fragments=50, shape="circle");

create_2d_path (points_set=points_6, width=1,
fragments=50, shape="circle");

create_2d_path (points_set=points_7, width=1,
fragments=50, shape="circle");

create_2d_path (points_set=points_8, width=1,
fragments=50, shape="circle");