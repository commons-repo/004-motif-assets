include<openscad_template.scad>

morew_points_1 = include <7-points-formatted_data_1.txt>;

morew_points_2 = include <8-points-formatted_data_2.txt>;

create_2d_path (points_set=morew_points_1, width=5,
fragments=50, shape="circle");

create_2d_path (points_set=morew_points_2, width=5,
fragments=50, shape="circle");