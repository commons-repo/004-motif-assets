include<openscad_template.scad>

ayus_points = include <6-points-formatted_data.txt>;

create_2d_path (points_set=ayus_points, width=3,
fragments=50, shape="circle");