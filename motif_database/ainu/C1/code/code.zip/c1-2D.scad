include<openscad_template.scad>

sik_points = include <7-points-formatted_data_1.txt>;

morew_points_1 = include <7-points-formatted_data_2.txt>;

morew_points_2 = include <7-points-formatted_data_3.txt>;

sik_points_m = include <8-points-formatted_data_1.txt>;

morew_points_1_m = include <8-points-formatted_data_2.txt>;

morew_points_2_m = include <8-points-formatted_data_3.txt>;

create_2d_path (points_set=sik_points , width=3,
fragments=50, shape="circle");

create_2d_path (points_set=morew_points_1, width=3,
fragments=50, shape="circle");

create_2d_path (points_set=morew_points_2, width=3,
fragments=50, shape="circle");

create_2d_path (points_set=sik_points_m , width=3,
fragments=50, shape="circle");

create_2d_path (points_set=morew_points_1_m, width=3,
fragments=50, shape="circle");

create_2d_path (points_set=morew_points_2_m, width=3,
fragments=50, shape="circle");