include<openscad_template.scad>

sik_points = include <7-points-formatted_data.txt>;

extrude_polygon (sik_points,height=10);
