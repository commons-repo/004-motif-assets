include<openscad_template.scad>

sik_points = include <7-points-formatted_data.txt>;

create_2d_path (points_set=sik_points, width=3,
fragments=50, shape="circle");