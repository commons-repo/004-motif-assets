include<openscad_template.scad>

sik_points = include <7-points-formatted_data.txt>;

extrude_2d_path (points_set=sik_points, width=5,
fragments=50, height=10, shape="circle");
