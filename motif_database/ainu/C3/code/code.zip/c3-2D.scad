include<openscad_template.scad>

points_1 = include <8-points-formatted_data_1.txt>;

points_2 = include <8-points-formatted_data_2.txt>;

points_3 = include <8-points-formatted_data_3.txt>;

points_4 = include <8-points-formatted_data_4.txt>;

points_5 = include <8-points-formatted_data_5.txt>;

points_6 = include <8-points-formatted_data_6.txt>;

points_7 = include <8-points-formatted_data_7.txt>;

points_8 = include <8-points-formatted_data_8.txt>;

points_9 = include <8-points-formatted_data_9.txt>;

translate([0.5,0,0])
create_2d_path (points_set=points_1, width=1.9,
fragments=50, shape="circle");

create_2d_path (points_set=points_2, width=1.9,
fragments=50, shape="circle");

create_2d_path (points_set=points_3, width=1.9,
fragments=50, shape="circle");

create_2d_path (points_set=points_4, width=1.9,
fragments=50, shape="circle");

create_2d_path (points_set=points_5, width=1.9,
fragments=50, shape="circle");

create_2d_path (points_set=points_6, width=1.9,
fragments=50, shape="circle");

create_2d_path (points_set=points_7, width=1.9,
fragments=50, shape="circle");

create_2d_path (points_set=points_8, width=1.9,
fragments=50, shape="circle");

create_2d_path (points_set=points_9, width=1.9,
fragments=50, shape="circle");