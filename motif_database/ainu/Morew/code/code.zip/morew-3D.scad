include<openscad_template.scad>

morew_points = include <6-points-formatted_data.txt>;

extrude_2d_path (points_set=morew_points, width=3,
fragments=50, height=10, shape="circle");
