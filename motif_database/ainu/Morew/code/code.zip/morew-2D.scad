include<openscad_template.scad>

morew_points = include <6-points-formatted_data.txt>;

create_2d_path (points_set=morew_points, width=3,
fragments=50, shape="circle");