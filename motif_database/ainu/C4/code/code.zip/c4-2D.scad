include<openscad_template.scad>

points_1 = include <7-points-formatted_data_1.txt>;

points_2 = include <7-points-formatted_data_2.txt>;

create_polygon (points_1);

create_polygon (points_2);