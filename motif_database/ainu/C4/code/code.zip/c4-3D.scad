include<openscad_template.scad>

points_1 = include <7-points-formatted_data_1.txt>;

points_2 = include <7-points-formatted_data_2.txt>;

$fn=100;

extrude_polygon (points_1,
height=10);

extrude_polygon (points_2,
height=10);
