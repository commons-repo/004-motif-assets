include<openscad_template.scad>

heart_points_1 = include <6-points-formatted_data_1.txt>;

heart_points_2 = include <6-points-formatted_data_2.txt>;

create_2d_path (points_set=heart_points_1, width=3,
fragments=50, shape="circle");

create_2d_path (points_set=heart_points_2, width=3,
fragments=50, shape="circle");