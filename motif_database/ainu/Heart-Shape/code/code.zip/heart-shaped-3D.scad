include<openscad_template.scad>

heart_points_1 = include <6-points-formatted_data_1.txt>;

heart_points_2 = include <6-points-formatted_data_2.txt>;

extrude_2d_path (points_set=heart_points_1, width=5,
fragments=50, height=10, shape="circle");

extrude_2d_path (points_set=heart_points_2, width=5,
fragments=50, height=10, shape="circle");
